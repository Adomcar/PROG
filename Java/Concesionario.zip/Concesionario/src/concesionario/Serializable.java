package concesionario;

public interface Serializable {
    public String serializar();
    public void deserializar(String datos);
}